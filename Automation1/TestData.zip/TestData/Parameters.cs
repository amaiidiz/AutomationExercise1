﻿using Automation1.Helpers.XML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomationTestConsole.TestData
{
    public class Parameters
    {
        private static string _url = string.Empty;
        private static string _user = string.Empty;
        private static string _password = string.Empty;

        public static string Url { get => _url; set => _url = value; }
        public static string User { get => _user; set => _user = value; }
        public static string Password { get => _password; set => _password = value; }

        public static void SetParameters()
        {
            XMLReader MyReader = new XMLReader();
            /*
            Url = "https://www.amazon.com.mx/";
            User = "eneida.montserrat@gmail.com";
            Password ="Converse1";  */

            Url = MyReader.GetConfigValue("applicationUrl");
            User = MyReader.GetConfigValue("username");
            Password = MyReader.GetConfigValue("password");
        }
    }
}
